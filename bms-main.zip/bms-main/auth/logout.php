<?php
// auth/logout.php
session_start();
$_SESSION = [];
session_destroy();
header("Location: /bms-main/auth/login.php");
exit;

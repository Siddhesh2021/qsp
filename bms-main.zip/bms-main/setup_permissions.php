<?php
// Quick setup script to add permissions to super_admin role
require_once __DIR__ . '/includes/db.php';

// Start transaction
$conn->begin_transaction();

try {
    // First, check what permissions exist
    $perms = $conn->query("SELECT * FROM permissions ORDER BY id");
    
    echo "<h2>Setting Up Permissions for Super Admin (Role ID: 1)</h2>";
    
    $permissionIds = [];
    echo "<h3>Available Permissions:</h3><ul>";
    while ($perm = $perms->fetch_assoc()) {
        $permissionIds[] = $perm['id'];
        echo "<li>ID: {$perm['id']} - {$perm['code']} - {$perm['description']}</li>";
    }
    echo "</ul>";
    
    if (empty($permissionIds)) {
        echo "<p style='color: red;'>❌ No permissions found in database!</p>";
        echo "<p>You need submit button...</p>";
    } else {
        // Delete existing mappings for super_admin (role_id = 1)
        $stmt = $conn->prepare("DELETE FROM role_permissions WHERE role_id = 1");
        $stmt->execute();
        echo "<p>✓ Cleared existing permissions for role 1</p>";
        
        // Insert all permissions for super_admin
        $stmt = $conn->prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (1, ?)");
        $inserted = 0;
        foreach ($permissionIds as $pid) {
            $stmt->bind_param("i", $pid);
            $stmt->execute();
            $inserted++;
        }
        echo "<p>✓ Assigned {$inserted} permissions to super_admin role</p>";
        
        $conn->commit();
        echo "<h3 style='color: green;'>✅ SUCCESS! Super admin now has all permissions.</h3>";
        echo "<p><a href='/bms-main/debug_roles.php'>Check Role Permissions</a></p>";
        echo "<p><a href='/bms-main/index.php'>Go to Dashboard</a></p>";
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    $conn->rollback();
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h3>Manual SQL Option:</h3>";
echo "<p>If the above didn't work, run this SQL in phpMyAdmin:</p>";
echo "<pre>";
echo "-- First check existing permissions\n";
echo "SELECT * FROM permissions;\n\n";
echo "-- Then assign all permissions to super_admin (replace 1,2,3... with actual permission IDs)\n";
echo "INSERT INTO role_permissions (role_id, permission_id) VALUES \n";
echo "  (1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8);\n";
echo "</pre>";
?>


<?php
// Debug script to check your role permissions
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

// session_start() is already called in helpers.php

echo "<h2>Role & Permission Debug Information</h2>";

// Check if logged in
if (!isLoggedIn()) {
    die("<p>❌ Not logged in. Please login first.</p>");
}

$userId = currentUserId();
$sessionRoleId = currentUserRoleId();

echo "<h3>Session Information</h3>";
echo "<p>User ID: <strong>{$userId}</strong></p>";
echo "<p>Session Role ID: <strong>{$sessionRoleId}</strong></p>";

// Check what role_id is in the database
$stmt = $conn->prepare("SELECT role_id, name, email FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$stmt->bind_result($dbRoleId, $userName, $email);
$stmt->fetch();
$stmt->close();

echo "<h3>Database Information</h3>";
echo "<p>User Name: <strong>{$userName}</strong></p>";
echo "<p>Email: <strong>{$email}</strong></p>";
echo "<p>Database Role ID: <strong>{$dbRoleId}</strong></p>";

// Highlight mismatch
if ($sessionRoleId != $dbRoleId) {
    echo "<p style='color: red; font-weight: bold;'>⚠️ MISMATCH! Session role ({$sessionRoleId}) ≠ Database role ({$dbRoleId})</p>";
    echo "<p><strong>Solution:</strong> Logout and login again to sync the session.</p>";
}

// Get role name
$stmt = $conn->prepare("SELECT name FROM roles WHERE id = ?");
$stmt->bind_param("i", $dbRoleId);
$stmt->execute();
$stmt->bind_result($roleName);
$stmt->fetch();
$stmt->close();

echo "<p>Role Name: <strong>{$roleName}</strong></p>";

// Get permissions for this role
$stmt = $conn->prepare("SELECT p.code, p.description 
                        FROM permissions p 
                        JOIN role_permissions rp ON rp.permission_id = p.id 
                        WHERE rp.role_id = ?");
$stmt->bind_param("i", $dbRoleId);
$stmt->execute();
$result = $stmt->get_result();

echo "<h3>Permissions Assigned to This Role (in Database)</h3>";
$perms = [];
while ($row = $result->fetch_assoc()) {
    $perms[] = $row['code'];
    echo "<p>✓ {$row['code']} - {$row['description']}</p>";
}
$stmt->close();

if (empty($perms)) {
    echo "<p style='color: red; font-weight: bold;'>❌ This role has NO permissions assigned!</p>";
    echo "<p>Go to: <a href='/bms-main/roles/edit_permissions.php?role_id={$dbRoleId}'>Edit Permissions for this Role</a></p>";
}

// Test specific permissions
echo "<h3>Testing Permissions (Using Session Role ID)</h3>";
$testPerms = ['book.create', 'book.edit', 'book.delete', 'user.view', 'user.create', 'user.edit', 'user.delete', 'role.manage'];
foreach ($testPerms as $perm) {
    $has = hasPermission($perm, $conn);
    $icon = $has ? '✅' : '❌';
    echo "<p>{$icon} {$perm}: " . ($has ? 'GRANTED' : 'DENIED') . "</p>";
}

echo "<hr>";
echo "<p><a href='/bms-main/index.php'>← Back to Dashboard</a></p>";

